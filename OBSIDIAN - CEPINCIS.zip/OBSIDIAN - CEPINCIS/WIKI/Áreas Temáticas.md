## Áreas Temáticas

As Áreas Temáticas nas quais serão alinhadas aos [[Projetos]] foram definidas para orientar as atividades do [[CEPIN-CIS]] e compreendem:

**(IoT)** 1- Desenvolvimento tecnológico e conectividade para cidades inteligentes e sustentáveis: Desenvolver tecnologias avançadas e soluções de conectividade para criar ambientes urbanos mais inteligentes, eficientes e sustentáveis.

**(CarbonZero**) 2- Descarbonização do ambiente construído: Promover a redução das emissões de carbono em edifícios, infraestrutura, mobilidade urbana, fontes de energia e saneamento ambiental.

**(UrbanSmart)** 3- Monitoramento e operações urbanas inteligentes: Desenvolver soluções para monitorar e gerenciar a infraestrutura urbana, utilizando tecnologias como gêmeos digitais, plataformas digitais, sistemas autônomos e drones, para otimizar o funcionamento de serviços essenciais e melhorar a resiliência climática.

**(EcoMat)** 4- Novos materiais e economia circular: Investigar materiais sustentáveis e promoção de economia circular, reduzindo o impacto ambiental.

**(EduCIS)** 5- Formação de recursos humanos para cidades inteligentes e sustentáveis: Desenvolvimento de recursos humanos e métodos ágeis de capacitação para impulsionar a inovação em Cidades Inteligentes e Sustentáveis.