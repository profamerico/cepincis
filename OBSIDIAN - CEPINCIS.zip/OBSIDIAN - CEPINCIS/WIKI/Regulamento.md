## Regulamento

O regulamento do [Centro de Pesquisa e Inovação em Cidades Inteligentes e Sustentáveis](CEPIN-CIS.md) ([[CEPIN-CIS]]) foi aprovado em 2024 pelo Conselho de Campus (CONCAM) do IFSP Caraguatatuba. Este marco normativo consolida a missão do [[CEPIN-CIS]] como espaço de fomento à pesquisa aplicada, à inovação tecnológica e à reflexão crítica sobre os desafios contemporâneos das cidades.

O regulamento estabelece as diretrizes para a participação de [servidores e discentes](Hierarquia) vinculados a [projetos de ensino, pesquisa](Projetos)[ ou extensão](Orientação) que dialoguem com as [[Áreas Temáticas]] do Centro, além de abrir espaço para a [colaboração de pesquisadores externos](Hierarquia).

[Portaria Normativa nº 14/2024 - Aprova regulamento CEPIN-CIS](https://www.ifspcaraguatatuba.edu.br/images/CEPIN/Portaria_Normativa_n%C2%BA_14-2024_Aprova_regulamento_CEPIN-CIS.pdf)