## Implementação

A implementação do CEPIN-CIS ocorreu durante os anos de 2022 e 2023, com recursos obtidos através do edital nº PRP/IFSP 329/2021. A equipe de implementação foi composta por:

Equipe de Implementação:

José Américo Alves Salvador Filho (coordenador) lattes.cnpq.br/8494783082862407

[jasalvador@ifsp.edu.br](mailto:jasalvador@ifsp.edu.br)

Adriana Marques lattes.cnpq.br/5040566445402531

[adriana.marques@ifsp.edu.br](mailto:adriana.marques@ifsp.edu.br)

Mario Tadashi Shimanuki lattes.cnpq.br/2673060331553099

[shimanuki@ifsp.edu.br](mailto:shimanuki@ifsp.edu.br)

Vassiliki Teresinha Galvão Boulomytis lattes.cnpq.br/9152140186894460

[vassiliki@ifsp.edu.br](mailto:vassiliki@ifsp.edu.br)