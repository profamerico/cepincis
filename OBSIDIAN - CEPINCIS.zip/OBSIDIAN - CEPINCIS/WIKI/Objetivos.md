## Objetivos

Os principais objetivos do [[CEPIN-CIS]] são desenvolver investigação fundamental ou aplicada focada em cidades inteligentes e sustentáveis, contribuir ativamente para a inovação por meio da transferência de tecnologia e oferecer atividades de extensão.