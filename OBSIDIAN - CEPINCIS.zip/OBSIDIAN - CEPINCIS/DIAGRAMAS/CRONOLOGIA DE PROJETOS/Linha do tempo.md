## Linha do Tempo
A linha do tempo dos [[Projetos]] pode ser criada por qualquer [membro do projeto](Hierarquia) (se ela ainda não existir) e pode ser editada da seguinte forma:

**Adição de Conteúdo:**
[Todos os membros] do [projeto](Projetos).

**Substituição de conteúdo:**
[Pesquisador Associado](Hierarquia) ou superior.

**Substituição de conteúdo:**
[Pesquisador Pleno](Hierarquia) ou superior.

Ela define as etapas em andamento do [projeto](Projetos), e o conteúdo finalizado e em desenvolvimento aparecem visíveis à [membros externos](Hierarquia) ao projeto.