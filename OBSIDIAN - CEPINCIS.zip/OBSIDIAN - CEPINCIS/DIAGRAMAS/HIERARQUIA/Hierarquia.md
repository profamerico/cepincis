## Hierarquia

**Pesquisador Acadêmico:**
São pesquisadores de todos os níveis acadêmicos, incluindo iniciação científica, trabalho de conclusão de curso, mestrado, doutorado, entre outros, bolsistas ou voluntários, envolvidos em [projetos de pesquisa e/ou extensão](Projetos) no âmbito ou em parceria com o [[CEPIN-CIS]] correlatos às [[Áreas Temáticas]] do [[CEPIN-CIS]] sob orientação ou supervisão de um Pesquisador Associado ou Pleno do CEPIN-CIS. As atribuições e carga horária dos pesquisadores acadêmicos estão correlacionadas com as diretrizes estabelecidas no edital correspondente à bolsa ou programa à qual estão vinculados.

**Pesquisador Associado:**
São pesquisadores do IFSP ou instituições parceiras orientadores de trabalhos de todos os níveis acadêmicos, incluindo iniciação científica, trabalho de conclusão de curso, mestrado, doutorado, pós-doutorado, entre outros, correlatos às [[Áreas Temáticas]] do [[CEPIN-CIS]] em [projetos de pesquisa e/ou extensão](Projetos) aprovados por edital interno ou externo, no âmbito ou em parceria com o [[CEPIN-CIS]]. Podem assim, desenvolver **[orientações](Orientação)** para o pesquisador acadêmico.

**Pesquisador Pleno:**
São pesquisadores do IFSP ou instituições parceiras envolvidos em [projetos de pesquisa e/ou extensão](Projetos) aprovados por edital interno ou externo, no âmbito ou em parceria com o [[CEPIN-CIS]]. Esses podem desenvolver **[orientações](Orientação)** e elaborar **[projetos](Projetos)** que seriam diretamente inseridos na página do [[CEPIN-CIS]].

[[Níveis de acesso no site.canvas]]
[[Relação Hierárquica.canvas]]