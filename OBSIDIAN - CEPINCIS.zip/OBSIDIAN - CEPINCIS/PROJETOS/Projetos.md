## Projetos

- Definidos pelos [pesquisadores/professores](Hierarquia) que desenvolvem [orientações](Orientação);
- Estará vinculada a ao menos uma [[Orientação]];
- Precisará de campo para resumo sobre o [projeto](Projetos), imagem e [pesquisadores](Hierarquia) que atuam neles;
- Deverá estar ligado a uma ou mais [[Áreas Temáticas]];
- Pode estar em criação, em andamento ou encerrado;
- Os projetos possuirão [[linha do tempo]] customizável.